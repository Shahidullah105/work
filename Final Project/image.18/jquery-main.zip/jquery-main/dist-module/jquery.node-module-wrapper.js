import jQuery from "../dist/jquery.js";
const $ = jQuery;
export { jQuery, $ };
export default jQuery;
