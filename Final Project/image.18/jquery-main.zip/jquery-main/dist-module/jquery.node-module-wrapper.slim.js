import jQuery from "../dist/jquery.slim.js";
const $ = jQuery;
export { jQuery, $ };
export default jQuery;
