export default ( /^(?:checkbox|radio)$/i );
