import class2type from "./class2type.js";

export default class2type.hasOwnProperty;
