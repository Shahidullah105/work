window.testMessage = "script run";
