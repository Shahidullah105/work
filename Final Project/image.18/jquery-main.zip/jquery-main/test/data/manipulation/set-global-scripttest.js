window.scriptTest = true;
parent.finishTest();
